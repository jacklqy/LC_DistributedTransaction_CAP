# 贡献

贡献最简单的方式之一就是参与讨论和issue讨论。

如果您有任何疑问或问题，请在CAP仓库中报告：

<a href="https://github.com/dotnetcore/cap/issues/new"><button data-md-color-primary="purple"><i class="fa fa-github fa-2x"></i> Report Issue</button></a>
<a href="https://github.com/dotnetcore/cap/issues"><button data-md-color-primary="purple" type="submit"> Active Issues <i class="fa fa-github fa-2x"></i></button></a>

## 提交更改

您还可以通过提交代码更改PR来做出贡献。

>
Pull requests 可让您告诉其他人已推送到GitHub上存储库的更改。 打开 Pull requests 后，您可以与协作者讨论和审查做出的更改，并在更改合并到存储库之前添加后续提交。

## 其他资源

* [issue 和 pull requests](https://help.github.com/articles/filtering-issues-and-pull-requests/)

* [使用搜索过滤 issue 和 pull requests](https://help.github.com/articles/using-search-to-filter-issues-and-pull-requests/)