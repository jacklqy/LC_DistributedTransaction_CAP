# Sagas

Sagas (also known in the literature as "process managers") are stateful services. You can think of them as state machines whose transitions are driven by messages.

## Sagas on CAP

TODO