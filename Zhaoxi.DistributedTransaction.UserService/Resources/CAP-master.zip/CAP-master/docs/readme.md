# CAP Documentation

The folder contains the documentation for CAP.

We are using [Github Pages](https://github.com/dotnetcore/CAP/tree/gh-pages) to host the documentation and the rendered version can be found [here](http://cap.dotnetcore.xyz).

Doc pages are authored in Markdown  - you can find a primer [here](https://help.gamejolt.com/markdown).
