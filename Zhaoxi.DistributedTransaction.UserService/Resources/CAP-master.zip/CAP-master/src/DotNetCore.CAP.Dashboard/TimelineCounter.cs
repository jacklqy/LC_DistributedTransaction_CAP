﻿namespace DotNetCore.CAP.Dashboard
{
    public class TimelineCounter
    {
        public string Key { get; set; }
        public int Count { get; set; }
    }
}
